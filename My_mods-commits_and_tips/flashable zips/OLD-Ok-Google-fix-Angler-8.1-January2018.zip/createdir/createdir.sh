#!/system/bin/sh
#make dir and parents dir
mkdir -p /system/priv-app/HotwordEnrollmentOKGoogleWCD9330/oat/arm64
mkdir -p /system/priv-app/HotwordEnrollmentTGoogleWCD9330/oat/arm64
mkdir -p /system/priv-app/HotwordEnrollmentXGoogleWCD9330/oat/arm64
#set folders permissions
chmod 755 /system/priv-app/HotwordEnrollmentOKGoogleWCD9330
chmod 755 /system/priv-app/HotwordEnrollmentOKGoogleWCD9330/oat
chmod 755 /system/priv-app/HotwordEnrollmentOKGoogleWCD9330/oat/arm64
chmod 755 /system/priv-app/HotwordEnrollmentTGoogleWCD9330
chmod 755 /system/priv-app/HotwordEnrollmentTGoogleWCD9330/oat
chmod 755 /system/priv-app/HotwordEnrollmentTGoogleWCD9330/oat/arm64
chmod 755 /system/priv-app/HotwordEnrollmentXGoogleWCD9330
chmod 755 /system/priv-app/HotwordEnrollmentXGoogleWCD9330/oat
chmod 755 /system/priv-app/HotwordEnrollmentXGoogleWCD9330/oat/arm64
#remove 8.0 Hotword apk
rm -rf /system/priv-app/HotwordEnrollmentWCD9330
exit 0
