#!/sbin/sh

#make dir and parents dir
mkdir -p /system/app/Gallery2/lib/arm
#set folders permissions
chmod 755 /system/app/Gallery2/
chmod 755 /system/app/Gallery2/lib
chmod 755 /system/app/Gallery2/lib/arm
exit 0
